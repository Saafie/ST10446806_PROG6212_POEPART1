﻿using System.Windows;

namespace ST10446806_PROG6212_POEPART1
{
    public partial class CoordinatorWindow : Window
    {
        public CoordinatorWindow()
        {
            InitializeComponent();
        }

        private void CloseButton(object sender, RoutedEventArgs i)
        {
            this.Close();
        }
    }
}



