# ST10446806_PROG6212_POEPART1
1st commit
This is just a LecturerWindow, its the part of the prototype that has buttons to allow for submission and entering hours and uploading documents due to part 1 asking for front end only, theres no functionality yet.

Upload doc button will allow for uploading documents Submit button submits claims from lecturers

My Claims It will contain all the claims the lecturer submitted and the claims will have a status shown of pending, approved by coordinator, rejected by coordinator, approved by manager and rejected by manager with the date it was submited, the claim ID, Amount, hours and date it was submitted.


2nd commit
Roles Window
Allows for the the user to choose between lecturer and coordinator. If lecturer is picked the lecturer window opens, if coordinator is picked the coordinator window opens. its not buttons its more or circles to pick from. It already has a colour skeem which is blue.

Coordinator Window
The coordinator window was added, It allows for coordinators to review the claims and reject or approve the claims.
It displays the ClaimID, amount, hours and the status of the claim. The close button allows for the window to close and show the roles window again.

Lecturer Window changes
Lecturer window allows for the user to press close to go back and press coordinator.

3rd commit
Added Manager window
It is similar to the Coordinator window, it will have the claims displayed where it will be approved or rejected. the claims will only show once the claims were approved or rejected by the coordinator. there are no examples now because a claim wasnt approved or rejected by coordinator, there is also a close button which will lead back to the roles window.

changes to Roles window
a cirlcle was added to be clicked for manager, a method was added so when manager is clicked is will lead to the manager window, the circles also colour was added.

4th commit
Lecturer, coordinator and manager window all got examples like this, the coordinator and manager window just has one example that allows approval or rejection.
Claim ID: 1 | 13h | R4550 | Submission Pending
    
Claim ID: 2 | 2h | R4550 | Rejected by Coordinator

Claim ID: 3 | 2 | R750 | Approved by coordinator
The time lines of the examples arent 100% correct its just to show what would happen if the prototype had functionality.
so the my claims in the lecturer window will give the status update of the claims.
